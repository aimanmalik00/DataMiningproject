from pipenv.patched.notpip._vendor.certifi import where
print(where())
